﻿using UnityEngine;
using System.Collections;

public class TestSelection : MonoBehaviour {

	public Texture2D selectionHighlight = null;		// for the selection square
	public static Rect selection = new Rect(0, 0, 0, 0);	// the selection square
	private Vector2 startClick = -Vector2.one; 		// the spot you click the mouse

	// Update is called once per frame
	void Update () {
		GetSelection ();	// run the process to get the selection square
	}

	void GetSelection() {
		if (Input.GetMouseButtonDown (0)) {
			startClick = Camera.main.ScreenToWorldPoint (Input.mousePosition);
		} else if (Input.GetMouseButtonUp(0)) {
			if (selection.width < 0) {
				selection.x = Mathf.Abs (selection.x += selection.width);
			}
			if (selection.height < 0) {
				selection.y = Mathf.Abs (selection.y += selection.height);
			}
			startClick = -Vector2.one;
		}

		// the below should make a box you click and drag
		if (Input.GetMouseButtonDown (0)) {
			selection = new Rect (startClick.x, startClick.y, Input.mousePosition.x - startClick.x, Input.mousePosition.y - startClick.y);
		}
	}

	private void OnGui(){
		if (startClick != -Vector2.one) {
			GUI.color = new Color (1, 1, 1, 0.5f);
			GUI.DrawTexture (selection, selectionHighlight);
		}
	}

}
