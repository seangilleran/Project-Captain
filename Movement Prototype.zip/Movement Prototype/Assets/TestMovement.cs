﻿using UnityEngine;
using System.Collections;

public class TestMovement : MonoBehaviour {

	Vector2 currentPosition;		// meant to track the character
	public float speed = 2f;		// movement speed

	// Use this for initialization
	void Start () {

		currentPosition = transform.position; // initialize the vector to the character's current position

	}
	
	// Update is called once per frame
	void Update () {
		if (Input.GetKeyDown (KeyCode.Mouse0)) {
			Debug.Log ("You left clicked!");
		}
		if (Input.GetKeyDown (KeyCode.Mouse1)) {
			currentPosition = Camera.main.ScreenToWorldPoint (Input.mousePosition); // game coordinates, not monitor
		}
		transform.position = Vector2.MoveTowards (transform.position, currentPosition, Time.deltaTime * speed); //move
	}
}
