﻿using UnityEngine;
using System.Collections;

public class TestMovement : MonoBehaviour {

	Vector2 currentPosition;		// meant to track the character
	Vector2 mouseClick;				// the last place the player clicked
	public float speed = 2f;		// movement speed
	public float characterSize = 0.5f;	// how large the character sprite is
	private bool isSelected = false; // checks to see if the character is selected

	// these collision detection things are workarounds while I test stuff out
	void OnCollisionEnter2D(Collision2D coll){
		currentPosition = transform.position; // this should stop it dead if it collides with something
		transform.rotation = Quaternion.identity; // should remove rotations
	}

	void OnCollisionStay2D(Collision2D coll){
		transform.rotation = Quaternion.identity; // should remove rotations
	}

	void OnCollisionExit2D(Collision2D coll){
		transform.rotation = Quaternion.identity; // should remove rotations
	}

	// Use this for initialization
	void Start () {

		currentPosition = transform.position; // initialize the vector to the character's current position

	}

	// Update is called once per frame
	void Update () {
		if (Input.GetKeyDown (KeyCode.Mouse0)) {
			mouseClick = Camera.main.ScreenToWorldPoint (Input.mousePosition); // sets a location where you clicked
			if (Mathf.Abs(mouseClick.x - currentPosition.x) <= characterSize	// if the x coordinate is close to the location
				&& Mathf.Abs(mouseClick.y - currentPosition.y) <= characterSize) { // if the y coordinate is also close
				isSelected = true;
			} else {
				isSelected = false;
			}
		}
		if (Input.GetKeyDown (KeyCode.Mouse1)) {
			if (isSelected && gameObject.tag == "Party"){ // this part only works if the unit is yours and is selected
				currentPosition = Camera.main.ScreenToWorldPoint (Input.mousePosition); // game coordinates, not monitor
			}
		}
		transform.position = Vector2.MoveTowards (transform.position, currentPosition, Time.deltaTime * speed); //move
	}
}
